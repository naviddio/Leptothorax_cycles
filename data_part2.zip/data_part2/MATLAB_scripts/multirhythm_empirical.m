clear all; close all

spectrum_Leptothorax=[];
for i=1:2 % loop through the two files (1 per species) of the 35-hr time series
    
    file={'C:\...\data\L.spW_35hr_colony.csv', 'C:\...\data\L.crassiplis_35hr_colony.csv'} ; % paths to the two files containing 35-hour time series
    activity_group=readtable(char(file(i))); % load the 35-hour time series for either L.spW or L.crassiplis

         for m=1:width(activity_group)-1 % loop through time series

            activity=activity_group(:,m+1); % subset the full matrix to extract the m-th time series
            activity_name=activity.Properties.VariableNames{1}; % get colony name
            activity_name=strrep(activity_name,'_long','');
            activity=table2array(activity);
            time=hours(seconds((1:length(activity))*30)); % time vector for plotting the x-axis in the tine series figures

            dz = detrend(activity,4); % detrend time series

            f12=smoothdata(activity,'gaussian',200); % smooth time series using a Gaussian-weighted moving average with a 200 point window
            f12=rescale(f12); % rescale time series to fall between 0 and 1 

            f129=smoothdata(activity,'gaussian',15); % smooth time series using a Gaussian-weighted moving average with a 15 point window
            f129=rescale(f129); % rescale time series to fall between 0 and 1 

            [pxx,f] = plomb(dz,1/30); % create Lomb-Scargle periodogram for the current, detrended time series  

            % generate plots of the 35 hour time series with 15-point (black lines) and 200-point smoothing windows (green lines)
            % Four of these plots were chosen to be featured in the main text (L4, L11, L16 & wisc_2_2018)

            figure
            plot(time,f129,'k','LineWidth',2)
            xlim([0 35])
            hold on
            plot(time,f12,'color', [0,1, 0.1250, 0.7],'LineWidth',5)
            set(gca,'fontsize',15)
            set(gca,'linewidth',2)
            set(gca,'TickDir','out')
            set(gca, 'FontName', 'Times')
            ylabel('Normalized activity')
            xlabel('Hours');
            title(char(activity_name), 'Interpreter', 'none')
            set(gcf,'Position',[100 100 500 200])
            a = gca;
            set(a,'box','off','color','none')
            b = axes('Position',get(a,'Position'),'box','on','xtick',[],'ytick',[]);
            set(b,'linewidth',2)
            axes(a)
            linkaxes([a b])

            % generate plots of the Lomb-Scargle periodograms from the 35 hour time series
            % Four of these plots were chosen to be featured in the main text (L4, L11, L16 & wisc_2_2018)

            figure
            plot(hours(seconds((1./f))),pxx,'LineWidth', 2)
            xlim([-0.5 9])
            set(gca,'linewidth',1)
            set(gca,'TickDir','out')
            set(gca, 'FontName', 'Times')
            title(char(activity_name), 'Interpreter', 'none')   
            ylabel('Power')
            xlabel('Cycle period (hrs)');
            a = gca;
            a.Color = 'k';
            set(a,'box','off','color','none')
            set(gcf,'Position',[100 100 100 150])        

            spectrum_Leptothorax=horzcat(spectrum_Leptothorax,rescale(pxx)); % update spectrum array


         end
    
    
end

% sum the periodograms of all 35-hour time series to produce figure 3 from the main text 
figure
plot(hours(seconds((1./f))),sum(spectrum_Leptothorax,2),'LineWidth', 2)
set(gca,'fontsize',15)
xlim([0 50])
ylabel('Sum of normalized power')
xlabel('Cycle period (min)');
a = gca;
a.Color = 'k';
set(a,'box','off','color','none')
set(gca, 'FontName', 'Times') 