clear all; close all
v2=[];

for o=1:4
    ap={'L.spW_9hr_colony.csv', 'L.spW_35hr_colony.csv', 'L.crassipilis_9hr_colony.csv', 'L.crassipilis_35hr_colony.csv'};
    ap2={'L.spW', 'L.spW', 'L.crassipilis', 'L.crassipilis'};
file=['C:\...\data\', char(ap(o))]; % path to a file containing time series (e.g., L.spW_9hr_colony, L.crassipilis_9hr_colony, L.spW_35hr_colony, etc.)
activity_group=readtable(file); % load time series from the specified file
 
name={}; % initialize variables
sp={};
num={};
fano=[];
peakmean=[];
period_wave=[];
 
    for m=1:width(activity_group)-1 % loop though each time series
 
        power=[];
        activity=activity_group(:,m+1); % load time series 
        
        f12=table2array(activity);
%         f12(isnan(f12))=0; % uncomment when analysing time series of isolated individuals to correct NaN values with 0s. 
        f12=smoothdata(f12,'gaussian',15); % smooth time series with Gaussian-weighted moving average 
        f12=rescale(f12); % rescale time series to fall between 0 and 1 
 
        [pks1,locs1,w1,p1] = findpeaks(f12,'MinPeakProminence',.2); % find peaks in the processed time series. 
        
        power=[];
        index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1/30); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);
        
        period_wave(m)=1/f(index1(Y))*0.01667; % compute the dominant period of oscillation using wavelet analysis for the m-th time series  
        
        name=vertcat(cellstr(name),cellstr(activity.Properties.VariableNames{1})); % add the name of the m-th time series to the names vector 
        fano(m)=std(diff(locs1))/mean(diff(locs1)); % compute the CV (i.e., Fano factor) for the m-th time series 
        peakmean(m)=mean(diff(locs1)*30*0.01667); % compute the mean IBI (inter-beat interval aka. mean time between activity peaks) for the m-th time series 
        sp=vertcat(cellstr(sp),char(ap2(o))); % add the species name associated with the m-th time series to the names vector 
 
 
    end
    
v=table(sp,name,period_wave',peakmean', fano'); % combine the colony ID, species name, CV, IBI, and dominant period of the m-th time series in a table.
v2=vertcat(v2,v); % append the data table of the m-th time series to a larger table containing the data from rest of the time series.   


end

v2.Properties.VariableNames ={'species' 'name' 'waveperiod' 'peakmean' 'CV'} %label column names

v2.species = categorical(v2.species);
Lcras = v2(v2.species =='L.crassipilis',:);
Lwisc = v2(v2.species =='L.spW',:);

%%

cd 'C:\...\data'

peakmean=[];
fanopeak=[];

opts = detectImportOptions('wisc_empirical_parameters.csv');
x2= readtable('wisc_empirical_parameters.csv',opts);

    


period9=[];
for m=1:width(x2)
    activityt4=x2(:,m);
    activityt4=table2array(activityt4);

     f12=smoothdata(activityt4,'gaussian',15);
     f12=rescale(f12);


power=[];
index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);

mag(m)=M;

period9(m)=1/f(index1(Y))/60;

m
    
    
end


%%

peakmean=[];
fanopeak=[];
opts = detectImportOptions('cras_empirical_parameters.csv');
x2= readtable('cras_empirical_parameters.csv',opts);

    


period95=[];
for m=1:width(x2)
    activityt4=x2(:,m);
    activityt4=table2array(activityt4);

     f12=smoothdata(activityt4,'gaussian',15);
     f12=rescale(f12);


power=[];
index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);

mag(m)=M;

period95(m)=1/f(index1(Y))/60;

    m
   
end

%%

peakmean=[];
fanopeak=[];

opts = detectImportOptions('wisc_5deg.csv');
x2= readtable('wisc_5deg.csv',opts);

periodw5=[];
for m=1:width(x2)
    activityt4=x2(:,m);
    activityt4=table2array(activityt4);

     f12=smoothdata(activityt4,'gaussian',15);
     f12=rescale(f12);


power=[];
index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);

mag(m)=M;

periodw5(m)=1/f(index1(Y))/60;

    m
   
end

opts = detectImportOptions('wisc_360deg.csv');
x2= readtable('wisc_360deg.csv',opts);

periodw360=[];
for m=1:width(x2)
     activityt4=x2(:,m);
    activityt4=table2array(activityt4);

     f12=smoothdata(activityt4,'gaussian',15);
     f12=rescale(f12);


power=[];
index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);

mag(m)=M;

periodw360(m)=1/f(index1(Y))/60;

   m 
   
end

opts = detectImportOptions('cras_5deg.csv');
x2= readtable('cras_5deg.csv',opts);

periodcras5=[];
for m=1:width(x2)
    activityt4=x2(:,m);
    activityt4=table2array(activityt4);

     f12=smoothdata(activityt4,'gaussian',15);
     f12=rescale(f12);


power=[];
index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);

mag(m)=M;

periodcras5(m)=1/f(index1(Y))/60;

m
    
   
end

opts = detectImportOptions('cras_360deg.csv');
x2= readtable('cras_360deg.csv',opts);

periodcras360=[];
for m=1:width(x2)
     activityt4=x2(:,m);
    activityt4=table2array(activityt4);

     f12=smoothdata(activityt4,'gaussian',15);
     f12=rescale(f12);


power=[];
index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);

mag(m)=M;

periodcras360(m)=1/f(index1(Y))/60;

m
    
   
end

refrac=padcat(period9', periodw5', periodw360', period95', periodcras5', periodcras360', Lwisc.waveperiod, Lcras.waveperiod);

a = .05;
b = -.05;
r1 = (b-a).*rand(length(refrac),1) + a;

r2 = (b-a).*rand(length(refrac),1) + a;

r3 = (b-a).*rand(length(refrac),1) + a;

r4 = (b-a).*rand(length(refrac),1) + a;

r5 = (b-a).*rand(length(refrac),1) + a;

r6 = (b-a).*rand(length(refrac),1) + a;

r7 = (b-a).*rand(length(refrac),1) + a;

r8 = (b-a).*rand(length(refrac),1) + a;

figure
 set(gcf,'Position',[100 100 800 450])


boxplot(refrac,'OutlierSize',0.00000001, 'Colors','bbbbbbkk')
hold on
scatter((ones(length(refrac),1).*1)+r1,refrac(:,1),150,'.', 'b')
hold on
scatter((ones(length(refrac),1).*2)+r2,refrac(:,2),150,'.' , 'b')
hold on
scatter((ones(length(refrac),1).*3)+r3,refrac(:,3),150,'.', 'b')
hold on
scatter((ones(length(refrac),1).*4)+r4,refrac(:,4),150,'.' , 'b')
hold on
scatter((ones(length(refrac),1).*5)+r5,refrac(:,5),150,'.', 'b')
hold on
scatter((ones(length(refrac),1).*6)+r6,refrac(:,6),150,'.' , 'b')
hold on
scatter((ones(length(refrac),1).*7)+r7,refrac(:,7),150,'.', 'k')
hold on
scatter((ones(length(refrac),1).*8)+r8,refrac(:,8),150,'.' , 'k')
ylim([0 200])
set(gca,'xticklabel',{'L. sp w 45','L. sp w 5', 'L. sp w 360', 'L. crassipilis 45', 'L. crassipilis 5', 'L. crassipilis 360', 'L. sp w','L. crassipilis'})
ylabel('Period (min)', 'FontWeight', 'Bold')
yticks([0:20:200])
set(gca,'fontsize',10)
set(gca,'linewidth',1)
set(gca,'TickDir','out')
set(gca, 'FontName', 'Times')
set(findobj(gca,'type','line'),'linew',2)

refrac=table(refrac(:,1), refrac(:,2), refrac(:,3), refrac(:,4), refrac(:,5), refrac(:,6), refrac(:,7), refrac(:,8))
refrac.Properties.VariableNames ={'L. sp w (sim) 45', 'L. sp w (sim) 5', 'L. sp w (sim) 360', 'L. crassipilis (sim) 45', 'L. crassipilis (sim) 5', 'L. crassipilis (sim) 360','L. sp w','L. crassipilis'}
