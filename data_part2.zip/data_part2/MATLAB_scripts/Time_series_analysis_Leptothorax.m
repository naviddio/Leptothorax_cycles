clear all; close all
v2=[];
 
file='C:\...\data\L.spW_9hr_colony.csv'; % path to a file containing time series (e.g., L.spW_9hr_colony, L.crassipilis_9hr_colony, L.spW_35hr_colony, etc.)
activity_group=readtable(file); % load time series from the specified file
 
name={}; % initialize variables
sp={};
num={};
fano=[];
peakmean=[];
period_wave=[];
 
    for m=1:width(activity_group)-1 % loop though each time series
 
        power=[];
        activity=activity_group(:,m+1); % load time series 
        
        f12=table2array(activity);
%         f12(isnan(f12))=0; % uncomment when analysing time series of isolated individuals to correct NaN values with 0s. 
        f12=smoothdata(f12,'gaussian',15); % smooth time series with Gaussian-weighted moving average 
        f12=rescale(f12); % rescale time series to fall between 0 and 1 
 
        [pks1,locs1,w1,p1] = findpeaks(f12,'MinPeakProminence',.2); % find peaks in the processed time series. 
        
        power=[];
        index1=[];
        [dpoaeCWT,f,coi] = cwt(f12, 1/30); % wavelet analysis
        for j=1:length(f12)
            cfsOAE = dpoaeCWT(:,j);
            q=abs(cfsOAE);
            h=horzcat(q,f);
            ex=coi(j);
            q2 = h(:,2) < ex; % exclude data points in the cone of influence 
            q(q2) = [];
            [power(j), index1(j)] = max(q);
        end
        wcom=horzcat(power',index1');
        [M,Y] = max(power);
        
        period_wave(m)=1/f(index1(Y))*0.01667; % compute the dominant period of oscillation using wavelet analysis for the m-th time series  
        
        name=vertcat(cellstr(name),cellstr(activity.Properties.VariableNames{1})); % add the name of the m-th time series to the names vector 
        fano(m)=std(diff(locs1))/mean(diff(locs1)); % compute the CV (i.e., Fano factor) for the m-th time series 
        peakmean(m)=mean(diff(locs1)*30*0.01667); % compute the mean IBI (inter-beat interval aka. mean time between activity peaks) for the m-th time series 
        sp=vertcat(cellstr(sp),cellstr('L.spW')); % add the species name associated with the m-th time series to the names vector 
 
 
    end
 
v=table(sp,name,period_wave',peakmean', fano'); % combine the colony ID, species name, CV, IBI, and dominant period of the time series in a table.   
v.Properties.VariableNames ={'species' 'name' 'waveperiod' 'peakmean' 'CV'} %label column names
 
% writetable(v,'L.spW_9hr_agg_15.txt')


