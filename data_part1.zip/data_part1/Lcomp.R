



# CV_agg
agg<-read.csv("CV_agg.csv", header=T)

wisc <- subset(agg, species == "wisc" & num =='1')

wisccolony <- subset(agg, species == "wisc" & num =='colony')

cras <- subset(agg, species == "cras" & num =='1')

crascolony <- subset(agg, species == "cras" & num =='colony')

ks.test(wisccolony$waveperiod,crascolony$waveperiod)

mean(wisccolony$waveperiod)
sd(wisccolony$waveperiod)

mean(crascolony$waveperiod)
sd(crascolony$waveperiod)

min(crascolony$waveperiod)
max(crascolony$waveperiod)

cor.test(wisccolony$colony_size,wisccolony$waveperiod)
cor.test(crascolony$colony_size,crascolony$waveperiod)


mean(wisc$fanopeak)
sd(wisc$fanopeak)

mean(cras$fanopeak)
sd(cras$fanopeak)

mean(wisc$peakmean)
sd(wisc$peakmean)

mean(cras$peakmean)
sd(cras$peakmean)


library(gdata)
ind<-combine(wisc,cras)

#t.test(fanopeak~source, data=ind)

library(nlme)
ind$source<-relevel(ind$source,"cras")
m1 <- lme(fanopeak ~ source ,random=~1|name,data=ind)
summary(m1)

m1 <- lme(peakmean ~ source ,random=~1|name,data=ind)
summary(m1)


# Ind stimulation
library(survival)
library(lme4)
library(ggfortify)
dat<-read.csv("refractive.csv", header=T)

SurvObj <- with(dat, Surv(time, activate == 1))
dat$SurvObj <- with(dat, Surv(time, activate == 1))
km.as.one <- survfit(SurvObj ~ species, data = dat, conf.type = "log-log")

dat$species<-as.factor(dat$species)
dat$species<-relevel(dat$species,"L_sp_w")
model <- glmer(activate ~ time+species+interaction_no.+time*species+interaction_no.*species + (1|colony), family="binomial",data=dat)
summary(model)


autoplot(km.as.one)+ theme_bw() + 
  xlab("Time since inactivation (min)") + ylab("Stimulations ignored") +
  theme(text=element_text(size=25,  family="serif"))+ 
  scale_color_manual(values = c("black","red"))+ 
  scale_fill_manual(values = c("#404040","red"))+
  theme(panel.border = element_rect(fill=NA, color="black"), 
        legend.position=c(0.15,0.5),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(fill="white"))

z<-survfit(Surv(time, activate == 1) ~ species,data=dat)
survdiff(Surv(time, activate == 1) ~ species,data=dat)





dat<-read.csv("refractivesample.csv", header=T)

wisc<-subset(dat, species == "spw")

cras<-subset(dat, species == "crassipilis")

ks.test(cras$stime, wisc$stime)




dat<-read.csv("refractiverepeat.csv", header=T)

wisc4<-subset(dat, event == 4 & colony == "wisc_5_2019")

cras4<-subset(dat, event == 4 & colony == "LC4")

dat2<-subset(dat, event == 4)

m1 <- lme(rtime ~ colony ,random=~1|ant,data=dat2)
summary(m1)















#Figure S1

plot(crascolony$colony_size,crascolony$fanopeak, las = 1, ylab = "", xlab = "", pch = 15, cex.main=2, cex.axis = 1.1, ylim = c(0.1, 1), xlim = c(0, 255))
points(wisccolony$colony_size,wisccolony$fanopeak, las = 1, ylab = "", xlab = "", pch = 19, col="red")
mtext(side = 2, family="sans", text = "CV", line = 2.9, cex=1.3)
mtext(side = 1, family="sans", text = "No. of ants", line = 2.9, cex=1.3)
z<-lm(fanopeak ~ colony_size, data = wisccolony)
abline(z, lwd = 2, col ="red")
z<-lm(fanopeak ~ colony_size, data = crascolony)
abline(z, lwd = 2, col ="black")

cor.test(wisccolony$colony_size,wisccolony$fanopeak)
cor.test(crascolony$colony_size,crascolony$fanopeak)


plot(crascolony$colony_size,crascolony$peakmean, las = 1, ylab = "", xlab = "", pch = 15, cex.main=2, cex.axis = 1.1, ylim = c(0, 300), xlim = c(0, 255))
points(wisccolony$colony_size,wisccolony$peakmean, las = 1, ylab = "", xlab = "", pch = 19, col="red")
mtext(side = 2, family="sans", text = "Mean IBI", line = 2.9, cex=1.3)
mtext(side = 1, family="sans", text = "No. of ants", line = 2.9, cex=1.3)
z<-lm(peakmean ~ colony_size, data = wisccolony)
abline(z, lwd = 2, col ="red")
z<-lm(peakmean ~ colony_size, data = crascolony)
abline(z, lwd = 2, col ="black")

cor.test(wisccolony$colony_size,wisccolony$peakmean)
cor.test(crascolony$colony_size,crascolony$peakmean)


plot(crascolony$colony_size,crascolony$waveperiod, las = 1, ylab = "", xlab = "", pch = 15, cex.main=2, cex.axis = 1.1, ylim = c(5, 150), xlim = c(0, 255))
points(wisccolony$colony_size,wisccolony$waveperiod, las = 1, ylab = "", xlab = "", pch = 19, col="red")
mtext(side = 2, family="sans", text = "Dominant STAC period (min)", line = 2.9, cex=1.3)
mtext(side = 1, family="sans", text = "No. of ants", line = 2.9, cex=1.3)
z<-lm(waveperiod ~ colony_size, data = wisccolony)
abline(z, lwd = 2, col ="red")
z<-lm(waveperiod ~ colony_size, data = crascolony)
abline(z, lwd = 2, col ="black")

cor.test(wisccolony$colony_size,wisccolony$waveperiod)
cor.test(crascolony$colony_size,crascolony$waveperiod)
